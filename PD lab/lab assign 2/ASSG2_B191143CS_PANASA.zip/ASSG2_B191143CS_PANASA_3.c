#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<limits.h>
int re_s(int a[],int l,int h,int k)
{
int m;
m=(l+h)/2;
if(l>h) return -1;
if(l<=h){
if(a[m]==k) return m;
if(k<a[m]) return re_s(a,l,m-1,k);
else return re_s(a,m+1,h,k);
}
}
int main(){
long long int n;
int i,j,*a,t,r,f;
scanf("%lld",&n);
scanf("%d",&t);
a=(int*)malloc(n*sizeof(int));
for(i=0;i<n;i++)
scanf("%d",&a[i]);
for(i=0;i<t;i++){
scanf("%d",&r);
f=re_s(a,0,n-1,r);
for(j=f-1;j>=0;j--){
if(a[j]==a[j+1])
f=j;
else 
break;}
printf("%d\n",f);
}
return 0;
}
